<?php
/**
 * Plugin Name: 图片本地化
 * Description: 在编辑器编辑文章时，可以把其中的远程图片保存到本地服务器中
 * Author: A.J
 * Version: V1.0
 * Plugin URL: www.Catfish-cms.com
 * Appliance: all
 */
namespace app\plugins\imagelocal;

use app\common\Plugin;

class Imagelocal extends Plugin
{
    private $plugin = 'imagelocal';
    public function open(&$params)
    {
        $this->statement('Catfish all plugin');
        //$this->set($this->plugin.'_delete_data',0);//关闭插件时是否删除数据
        //$this->set($this->plugin.'_error_message','');//错误信息
        //$this->set($this->plugin.'_ok_message','');//成功信息
    }
    public function close(&$params)
    {
        if($this->get($this->plugin.'_delete_data') == 1)
        {
            //关闭插件时需要删除的数据
        }
        //$this->delete($this->plugin.'_error_message');
        //$this->delete($this->plugin.'_ok_message');
        //$this->delete($this->plugin.'_delete_data');
    }
    public function settings(&$params)
    {
        //后台设置view
        //$params['view'] = ''.$this->import('js/imagelocal.js');
    }
    public function settings_post(&$params)
    {

    }
    public function write(&$params)
    {
        $params['content'] = $this->il($params['content']);
    }
    public function rewrite(&$params)
    {
        $params['content'] = $this->il($params['content']);
    }
    private function il($content)
    {
        if(preg_match_all('/\<img [^\>]*src="(data:image\/([^"]+);base64,([^"]+))"/', $content, $match)){
            $imgs = [];
            foreach($match[1] as $key => $val){
                $imgs[] = [
                    'rep' => $val,
                    'ext' => $match[2][$key],
                    'pic' => $match[3][$key]
                ];
            }
            if(count($imgs) > 0){
                $domain = $this->domain();
                list($subpath, $path) = $this->subpath();
                $url = rtrim($domain, '/') . '/' . str_replace('\\', '/', $subpath);
                foreach($imgs as $key => $val){
                    $ext = $val['ext'];
                    $extarr = explode('/', $ext);
                    $ext = $extarr[0];
                    $name = md5(uniqid()) . '.' . $ext;
                    file_put_contents($path . DS . $name, base64_decode($val['pic']));
                    $content = str_replace($val['rep'], $url . '/' . $name, $content);
                }
            }
        }
        if(preg_match_all('/\<img [^\>]*src="([^"]+)"/', $content, $match)){
            $imgs = [];
            $domain = $this->domain();
            foreach($match[1] as $key => $val){
                if(strpos($val, $domain) === false){
                    $imgs[] = $val;
                }
            }
            if(count($imgs) > 0){
                list($subpath, $path) = $this->subpath();
                $url = rtrim($domain, '/') . '/' . str_replace('\\', '/', $subpath);
                foreach($imgs as $key => $val){
                    if($img = file_get_contents($val)){
                        $name = basename($val);
                        if(false !== $wh = strpos($name, '?')){
                            $name = substr($name, 0, $wh);
                        }
                        file_put_contents($path . DS . $name, $img);
                        $content = str_replace($val, $url . '/' . $name, $content);
                    }
                }
            }
        }
        return $content;
    }
    private function subpath()
    {
        $subpath = 'data' . DS . 'uploads' . DS . date('Ymd');
        $path = ROOT_PATH . $subpath;
        if(!is_dir($path)){
            @mkdir($path, 0777, true);
        }
        return [$subpath, $path];
    }
}