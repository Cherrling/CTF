<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2022/3/4
 */
echo phpinfo();