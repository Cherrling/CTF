<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => '公告',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => '公告插件可以在首页的顶部显示一条公告',
    'Notice content' => '公告内容',
    'Save' => '保存'
];